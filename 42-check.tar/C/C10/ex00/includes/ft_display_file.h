#ifndef FT_DISPLAY_FILE_H
#define FT_DISPLAY_FILE_H

#include <unistd.h>
#include <fcntl.h>

int	ft_display_file(int fd);

#endif
