#include "ft_list.h"

void	ft_list_clear(t_lis *begin_list, void (*free_fct)(void *))
{
	int i;
}
